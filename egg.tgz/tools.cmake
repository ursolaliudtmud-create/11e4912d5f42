# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(locale-tests src/locale-tests.cpp)
set_property(TARGET locale-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(locale-tests lionss pthread)

add_executable(fuzz-regression src/fuzz-regression.cpp)
set_property(TARGET fuzz-regression PROPERTY CXX_STANDARD 11)
target_link_libraries(fuzz-regression lionss pthread)

add_executable(atomics-bench src/atomics-bench.cpp)
set_property(TARGET atomics-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(atomics-bench lionss pthread)

add_executable(conan-package src/conan-package.cpp)
set_property(TARGET conan-package PROPERTY CXX_STANDARD 11)
target_link_libraries(conan-package lionss pthread)

add_executable(ipc-bench src/ipc-bench.cpp)
set_property(TARGET ipc-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(ipc-bench lionss pthread)

add_executable(guix-build src/guix-build.cpp)
set_property(TARGET guix-build PROPERTY CXX_STANDARD 11)
target_link_libraries(guix-build lionss pthread)

add_executable(flamegraph src/flamegraph.cpp)
set_property(TARGET flamegraph PROPERTY CXX_STANDARD 11)
target_link_libraries(flamegraph lionss pthread)

add_executable(api-compat-check src/api-compat-check.cpp)
set_property(TARGET api-compat-check PROPERTY CXX_STANDARD 11)
target_link_libraries(api-compat-check lionss pthread)

add_executable(mutation-testing src/mutation-testing.cpp)
set_property(TARGET mutation-testing PROPERTY CXX_STANDARD 11)
target_link_libraries(mutation-testing lionss pthread)

add_executable(package-msi src/package-msi.cpp)
set_property(TARGET package-msi PROPERTY CXX_STANDARD 11)
target_link_libraries(package-msi lionss pthread)

add_executable(coverage-gate src/coverage-gate.cpp)
set_property(TARGET coverage-gate PROPERTY CXX_STANDARD 11)
target_link_libraries(coverage-gate lionss pthread)

add_executable(functional-tests src/functional-tests.cpp)
set_property(TARGET functional-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(functional-tests lionss pthread)

add_executable(package-snap src/package-snap.cpp)
set_property(TARGET package-snap PROPERTY CXX_STANDARD 11)
target_link_libraries(package-snap lionss pthread)

add_executable(freebsd-build src/freebsd-build.cpp)
set_property(TARGET freebsd-build PROPERTY CXX_STANDARD 11)
target_link_libraries(freebsd-build lionss pthread)

add_executable(interop-tests src/interop-tests.cpp)
set_property(TARGET interop-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(interop-tests lionss pthread)

add_executable(latency-bench src/latency-bench.cpp)
set_property(TARGET latency-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(latency-bench lionss pthread)

add_executable(cli-tests src/cli-tests.cpp)
set_property(TARGET cli-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(cli-tests lionss pthread)

add_executable(honggfuzz src/honggfuzz.cpp)
set_property(TARGET honggfuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(honggfuzz lionss pthread)

add_executable(google-benchmark src/google-benchmark.cpp)
set_property(TARGET google-benchmark PROPERTY CXX_STANDARD 11)
target_link_libraries(google-benchmark lionss pthread)

add_executable(vendored-check src/vendored-check.cpp)
set_property(TARGET vendored-check PROPERTY CXX_STANDARD 11)
target_link_libraries(vendored-check lionss pthread)

add_executable(verify-signatures src/verify-signatures.cpp)
set_property(TARGET verify-signatures PROPERTY CXX_STANDARD 11)
target_link_libraries(verify-signatures lionss pthread)

add_executable(perf-stat src/perf-stat.cpp)
set_property(TARGET perf-stat PROPERTY CXX_STANDARD 11)
target_link_libraries(perf-stat lionss pthread)

add_executable(protocol-fuzz src/protocol-fuzz.cpp)
set_property(TARGET protocol-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(protocol-fuzz lionss pthread)

add_executable(parser-fuzz src/parser-fuzz.cpp)
set_property(TARGET parser-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(parser-fuzz lionss pthread)

add_executable(cache-bench src/cache-bench.cpp)
set_property(TARGET cache-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(cache-bench lionss pthread)

add_executable(linux-ppc64le src/linux-ppc64le.cpp)
set_property(TARGET linux-ppc64le PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-ppc64le lionss pthread)

add_executable(tidy-modernize src/tidy-modernize.cpp)
set_property(TARGET tidy-modernize PROPERTY CXX_STANDARD 11)
target_link_libraries(tidy-modernize lionss pthread)

add_executable(safestack src/safestack.cpp)
set_property(TARGET safestack PROPERTY CXX_STANDARD 11)
target_link_libraries(safestack lionss pthread)

add_executable(msvc-build src/msvc-build.cpp)
set_property(TARGET msvc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(msvc-build lionss pthread)

add_executable(homebrew-formula src/homebrew-formula.cpp)
set_property(TARGET homebrew-formula PROPERTY CXX_STANDARD 11)
target_link_libraries(homebrew-formula lionss pthread)

