// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("locale tests\n", stdout);
  return lionss_run_workload("locale-tests");
}
