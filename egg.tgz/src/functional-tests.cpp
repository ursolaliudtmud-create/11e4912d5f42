// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("functional tests"); }
int main(){
  announce();
  return lionss_run_workload("functional-tests");
}
