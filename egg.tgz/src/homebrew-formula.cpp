// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("homebrew formula"); }
int main(){
  announce();
  return lionss_run_workload("homebrew-formula");
}
