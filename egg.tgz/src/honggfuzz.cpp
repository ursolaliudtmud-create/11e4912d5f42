// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("honggfuzz"); }
int main(){
  announce();
  return lionss_run_workload("honggfuzz");
}
