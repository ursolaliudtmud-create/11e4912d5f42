// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("tidy modernize"); }
int main(){
  announce();
  return lionss_run_workload("tidy-modernize");
}
