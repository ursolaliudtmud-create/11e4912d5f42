// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("perf stat\n", stdout);
  return lionss_run_workload("perf-stat");
}
