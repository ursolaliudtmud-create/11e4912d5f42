// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("google benchmark\n", stdout);
  return lionss_run_workload("google-benchmark");
}
