// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("mutation testing"); }
int main(){
  announce();
  return lionss_run_workload("mutation-testing");
}
